<?php
$cat   = $settings['blog_category'];

if (empty($cat)) {
	$best_wp = new wp_Query(array(
		'post_type'      => 'post',
		'posts_per_page' => $settings['per_page'],
	));
} else {
	$best_wp = new wp_Query(array(
		'post_type'      => 'post',
		'posts_per_page' => $settings['per_page'],
		'tax_query'      => array(
			array(
				'taxonomy' => 'category',
				'field'    => 'slug', //can be set to ID
				'terms'    => $cat //if field is ID you can reference by cat/term number
			),
		)
	));
}


while ($best_wp->have_posts()): $best_wp->the_post();
	$cats_show = get_the_term_list($best_wp->ID, 'category', ' ', '<span class="separator">,</span> ');

	$full_date      = get_the_date();
	$blog_date      = get_the_date('M d y');
	$post_admin     = get_the_author();
?>
	<div class="blog-item swiper-slide">
		<div class="image-part">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail($settings['thumbnail_size']); ?>
			</a>
			<?php if (($settings['blog_cat_show_hide'] == 'yes')) { ?>
				<div class="cat_list">
					<?php
					$categories = get_the_category();
					if (! empty($categories)) {
						$category_link = get_category_link($categories[0]->term_id);
						echo '<a href="' . esc_url($category_link) . '">' . esc_html($categories[0]->name) . '</a>';
					}
					?>
				</div>
			<?php } ?>
		</div>

		<div class="blog-content">
			<?php if (!empty($settings['blog_meta_show_hide']) && $settings['blog_meta_show_hide'] == 'yes') { ?>
				<ul class="blog-meta">
					<?php if (($settings['blog_avatar_show_hide'] == 'yes')) { ?>
						<?php if (!empty($post_admin)) { ?>
							<li>
								<span class="icon avatar-icon">
									<i class="tp tp-user-2"></i>
								</span>
								<span class="meta_text author">
									<?php echo esc_html__('By', 'tp-elements'); ?>
									<?php echo esc_html($post_admin); ?>
								</span>
							</li>
						<?php } ?>
					<?php } ?>

					<?php if (($settings['blog_date_show_hide'] == 'yes')) { ?>
						<li>
							<span class="icon calendar-icon">
								<i class="tp-clock-regular"></i>
							</span>
							<span class="meta_text date">
								<?php if (!empty($full_date)) { ?>
									<?php echo esc_html($full_date); ?>
								<?php } ?>
							</span>
						</li>
					<?php } ?>

				</ul>
			<?php } ?>

			<<?php echo $settings['title_tag'] ?> class="title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</<?php echo $settings['title_tag'] ?>>


			<?php if ($settings['blog_readmore_text'] || $settings['blog_readmore_icon']) : ?>
				<a class="tps-read-more " href="<?php the_permalink(); ?>">
					<?php if ($settings['blog_readmore_icon'] && $settings['blog_readmore_icon_position'] == 'left') : ?>
						<span class="icon <?php echo esc_attr($settings['blog_readmore_icon_position']); ?>">
							<i class="<?php echo esc_attr($settings['blog_readmore_icon']); ?>"></i>
						</span>
					<?php endif; ?>
					<?php echo $settings['blog_readmore_text']; ?>

					<?php if ($settings['blog_readmore_icon'] && $settings['blog_readmore_icon_position'] == 'right') : ?>
						<span class="icon <?php echo esc_attr($settings['blog_readmore_icon_position']); ?>">
							<i class="<?php echo esc_attr($settings['blog_readmore_icon']); ?>"></i>
						</span>
					<?php endif; ?>
				</a>
			<?php endif; ?>

		</div>
	</div>
<?php
endwhile;
wp_reset_query();
?>