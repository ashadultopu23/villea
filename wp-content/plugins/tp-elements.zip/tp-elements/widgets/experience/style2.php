<div class="circle-text second d-center cus-z1 tp-el-text-wrapper">
    <?php if (!empty($settings['experience_text'])) : ?>
        <div class="text">
            <p class="fs-nine text-uppercase p2-color tp-el-text"><?php echo esc_html($settings['experience_text']); ?></p>
        </div>
    <?php endif; ?>
    <div class="d-flex align-items-center justify-content-center rounded-circle cus-border tp-el-number-wrapper">
        <span class="heading fs-two tp-el-number d-flex align-items-center justify-content-center rounded-circle">
            <i class="tp-arrow-up-right"></i>
        </span>
    </div>
</div>