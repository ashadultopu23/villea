<?php

/**
 * Variable product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/variable.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.6.0
 */

defined('ABSPATH') || exit;


global $product;

$attribute_keys = array_keys($attributes);
$variations_json = wp_json_encode($available_variations);
$variations_attr = function_exists('wc_esc_json') ? wc_esc_json($variations_json) : _wp_specialchars($variations_json, ENT_QUOTES, 'UTF-8', true);

do_action('woocommerce_before_add_to_cart_form'); ?>

<form class="variations_form cart" action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>" data-product_variations="<?php echo esc_attr($variations_attr); ?>">
	<?php do_action('woocommerce_before_variations_form'); ?>

	<?php if (empty($available_variations) && false !== $available_variations) : ?>
		<p class="stock out-of-stock"><?php echo esc_html(apply_filters('woocommerce_out_of_stock_message', __('This product is currently out of stock and unavailable.', 'villea'))); ?></p>
	<?php else : ?>
		<div class="variations">
			<?php foreach ($attributes as $attribute_name => $options) : ?>
				<div class="variation-row mb-4">
					<label class="fs-5 mb-3 d-block"><?php echo wc_attribute_label($attribute_name); ?></label>
					<div class="value variation-options">
						<?php
						// Get selected value if exists
						$selected = isset($_REQUEST['attribute_' . sanitize_title($attribute_name)]) ? wc_clean(wp_unslash($_REQUEST['attribute_' . sanitize_title($attribute_name)])) : $product->get_variation_default_attribute($attribute_name);

						// Display options as clickable buttons
						// if (!empty($options)) {
						// 	// $terms = wc_get_product_terms($product->get_id(), $attribute_name, array('fields' => 'all'));

						// 	// foreach ($terms as $term) {
						// 	// 	if (in_array($term->slug, $options)) {
						// 	// 		$class = sanitize_title($term->slug);
						// 	// 		if ($selected == $term->slug) {
						// 	// 			$class .= ' active';
						// 	// 		}

						// 	// 		// For color variations, you might want to add additional styling
						// 	// 		// $color = get_term_meta($term->term_id, 'color', true);
						// 	// 		// $style = '';
						// 	// 		// if ($color) {
						// 	// 		// 	$style = 'style="background-color:' . esc_attr($color) . '"';
						// 	// 		// }

						// 	// 		// echo '<button type="button" class="variation-option ' . esc_attr($class) . '" data-value="' . esc_attr($term->slug) . '" ' . $style . '>';
						// 	// 		// echo esc_html(apply_filters('woocommerce_variation_option_name', $term->name));
						// 	// 		// echo '</button>';
						// 	// 	}
						// 	// }
						// }

						// Add hidden select element for WC to work with
						wc_dropdown_variation_attribute_options(
							array(
								'options'   => $options,
								'attribute' => $attribute_name,
								'product'   => $product,
								'class'    => 'hidden-select'
							)
						);

						// Reset link
						echo end($attribute_keys) === $attribute_name ? wp_kses_post(apply_filters('woocommerce_reset_variations_link', '<a class="reset_variations" href="#" aria-label="' . esc_attr__('Clear options', 'villea') . '">' . esc_html__('Clear', 'villea') . '</a>')) : '';
						?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="single_variation_wrap">
			<?php
			/**
			 * Hook: woocommerce_before_single_variation.
			 */
			do_action('woocommerce_before_single_variation');

			/**
			 * Hook: woocommerce_single_variation. Used to output the cart button and placeholder for variation data.
			 *
			 * @since 2.4.0
			 * @hooked woocommerce_single_variation - 10 Empty div for variation data.
			 * @hooked woocommerce_single_variation_add_to_cart_button - 20 Qty and cart button.
			 */
			do_action('woocommerce_single_variation');

			/**
			 * Hook: woocommerce_after_single_variation.
			 */
			do_action('woocommerce_after_single_variation');
			?>
		</div>
	<?php endif; ?>

	<?php do_action('woocommerce_after_variations_form'); ?>
</form>

<?php
do_action('woocommerce_after_add_to_cart_form');
